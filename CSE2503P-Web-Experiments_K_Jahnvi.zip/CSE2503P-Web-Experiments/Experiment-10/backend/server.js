import express from "express";
import cors from "cors";

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

const products = [
  { id: 1, name: "Laptop", category: "Electronics", price: 55000 },
  { id: 2, name: "Mobile Phone", category: "Electronics", price: 25000 },
  { id: 3, name: "Notebook", category: "Stationery", price: 100 },
  { id: 4, name: "Headphones", category: "Accessories", price: 1500 }
];

app.get("/api/products", (req, res) => {
  res.json(products);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
